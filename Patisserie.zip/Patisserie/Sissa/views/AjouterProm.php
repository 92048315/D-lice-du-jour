<?php
include "../core/promotionsC.php";

if (isset($_POST["taux"]) and isset($_POST["datefin"]) and isset($_POST["nom"]) and isset($_POST["produit"]))
{
    $f=new promotionC();
    $f->ajouterpromotion($_POST["taux"],$_POST["produit"],$_POST["datefin"],$_POST["nom"]);
    header("location:AfficherProm.php");


}
else
{
    echo"thabet rou7ek".$_POST["taux"].$_POST["produit"].$_POST["datefin"].$_POST["nom"]."";
}
